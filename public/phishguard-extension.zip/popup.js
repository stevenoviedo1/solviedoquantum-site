const $ = (id) => document.getElementById(id);

const LEVEL_COLOR = {
  CRITICAL: "#f43f5e",
  HIGH: "#fb7185",
  MEDIUM: "#f59e0b",
  LOW: "#34d399",
};

function paintResult(data) {
  const score = data?.risk_score ?? 0;
  const level = data?.risk_level || "LOW";
  const color = LEVEL_COLOR[level] || LEVEL_COLOR.LOW;
  const gauge = $("gauge");
  gauge.style.setProperty("--p", score);
  gauge.style.setProperty("--gauge", color);
  gauge.textContent = score;
  gauge.style.color = color;
  $("verdict").textContent = level;
  $("verdict").style.color = color;

  try {
    $("host").textContent = data?.url ? new URL(data.url).hostname : data?.urlEval?.host || "";
  } catch {
    $("host").textContent = data?.url || "";
  }

  if (data?.allowlisted || data?.urlEval?.allowlisted) {
    $("allow-note").style.display = "block";
  }

  const findings = [
    ...(data?.page?.findings || []),
    ...(data?.urlEval?.findings || []),
    ...(data?.findings || []),
  ].slice(0, 6);

  const ul = $("findings");
  ul.innerHTML = "";
  if (!findings.length) {
    ul.innerHTML = `<li><span>OK</span>No strong automated red flags on this tab.</li>`;
    return;
  }
  for (const f of findings) {
    const li = document.createElement("li");
    li.innerHTML = `<span>${(f.sev || f.severity || "info").toUpperCase()}</span>${escapeHtml(f.msg || f.message || "")}`;
    ul.appendChild(li);
  }
}

function escapeHtml(s) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function loadSettingsIntoUi(s) {
  $("enabled").checked = s.enabled !== false;
  $("notifications").checked = s.notifications !== false;
  $("formShield").checked = s.formShield !== false;
  $("linkHover").checked = s.linkHover !== false;
  $("sensitivity").value = s.sensitivity || "balanced";
  const stats = s.stats || {};
  $("stat-pages").textContent = stats.pagesScanned || 0;
  $("stat-threats").textContent = stats.threatsBlocked || 0;
}

function saveToggle() {
  chrome.runtime.sendMessage({
    type: "SET_SETTINGS",
    payload: {
      enabled: $("enabled").checked,
      notifications: $("notifications").checked,
      formShield: $("formShield").checked,
      linkHover: $("linkHover").checked,
      sensitivity: $("sensitivity").value,
    },
  });
}

async function scan() {
  $("verdict").textContent = "Scanning…";
  $("verdict").style.color = "#94a3b8";
  chrome.runtime.sendMessage({ type: "SCAN_TAB" }, (res) => {
    if (chrome.runtime.lastError) {
      $("verdict").textContent = "Restricted page";
      $("host").textContent = "Cannot inject into this URL";
      return;
    }
    paintResult(res || {});
    chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, loadSettingsIntoUi);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, loadSettingsIntoUi);
  scan();

  ["enabled", "notifications", "formShield", "linkHover", "sensitivity"].forEach((id) => {
    $(id).addEventListener("change", saveToggle);
  });

  $("scan-btn").addEventListener("click", scan);

  $("trust-btn").addEventListener("click", () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (!tab?.url) return;
      try {
        const domain = new URL(tab.url).hostname;
        chrome.runtime.sendMessage({ type: "ALLOWLIST_ADD", domain }, () => {
          $("allow-note").style.display = "block";
          $("allow-note").textContent = `Trusted ${domain}`;
          scan();
        });
      } catch (_) { /* ignore */ }
    });
  });

  $("options-btn").addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });

  $("demo-btn").addEventListener("click", () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]?.id) return;
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: () => {
          const id = "phishguard-banner";
          if (document.getElementById(id)) return;
          const el = document.createElement("div");
          el.id = id;
          el.style.cssText =
            "position:fixed;top:0;left:0;right:0;z-index:2147483647;display:flex;gap:12px;align-items:center;justify-content:center;padding:14px;font:600 14px system-ui;color:#e8eefc;background:linear-gradient(90deg,#0b1224,#1a1030);border-bottom:2px solid #22d3ee";
          el.innerHTML =
            '<span style="color:#67e8f9">PhishGuard DEMO</span> Real alerts appear automatically on suspicious pages. <button style="padding:8px 12px;border:none;border-radius:8px;font-weight:700;background:linear-gradient(135deg,#22d3ee,#8b5cf6);color:#041018;cursor:pointer">OK</button>';
          document.documentElement.appendChild(el);
          el.querySelector("button").onclick = () => el.remove();
          setTimeout(() => el.remove(), 5000);
        },
      });
      window.close();
    });
  });
});
