/**
 * PhishGuard MV3 service worker — URL checks, badge, notifications, stats.
 */
importScripts("rules-engine.js");

const Engine = self.PhishGuardEngine;

const DEFAULTS = {
  enabled: true,
  sensitivity: "balanced",
  notifications: true,
  formShield: true,
  linkHover: true,
  allowlist: [],
  stats: { pagesScanned: 0, threatsBlocked: 0, lastThreat: null },
};

async function getSettings() {
  const data = await chrome.storage.sync.get(DEFAULTS);
  return { ...DEFAULTS, ...data };
}

async function setStats(patch) {
  const s = await getSettings();
  const stats = { ...s.stats, ...patch };
  await chrome.storage.sync.set({ stats });
  return stats;
}

function allowlisted(url, allowlist) {
  try {
    const host = new URL(url).hostname.toLowerCase();
    return (allowlist || []).some(
      (d) => host === d || host.endsWith("." + d.replace(/^\./, ""))
    );
  } catch {
    return false;
  }
}

function badgeFor(level, score) {
  if (!level || level === "LOW" || score < 30) {
    return { text: "", color: "#22d3ee" };
  }
  if (level === "CRITICAL") return { text: "!!", color: "#f43f5e" };
  if (level === "HIGH") return { text: "!", color: "#fb7185" };
  return { text: "?", color: "#f59e0b" };
}

async function evaluateTab(tabId, url) {
  const settings = await getSettings();
  if (!settings.enabled || !url || url.startsWith("chrome://") || url.startsWith("chrome-extension://") || url.startsWith("edge://")) {
    await chrome.action.setBadgeText({ tabId, text: "" });
    return null;
  }
  if (allowlisted(url, settings.allowlist)) {
    await chrome.action.setBadgeText({ tabId, text: "OK" });
    await chrome.action.setBadgeBackgroundColor({ tabId, color: "#34d399" });
    return { risk_level: "LOW", risk_score: 0, allowlisted: true };
  }

  const urlResult = Engine.analyzeUrl(url);
  let score = urlResult.score;
  let level = score >= 70 ? "CRITICAL" : score >= 50 ? "HIGH" : score >= 30 ? "MEDIUM" : "LOW";

  // Sensitivity adjust
  if (settings.sensitivity === "strict" && score >= 22) {
    if (level === "LOW") level = "MEDIUM";
  }
  if (settings.sensitivity === "quiet" && score < 40) {
    level = "LOW";
  }

  const badge = badgeFor(level, score);
  await chrome.action.setBadgeText({ tabId, text: badge.text });
  await chrome.action.setBadgeBackgroundColor({ tabId, color: badge.color });

  const stats = await getSettings().then((s) => s.stats || DEFAULTS.stats);
  await setStats({
    pagesScanned: (stats.pagesScanned || 0) + 1,
    lastThreat:
      level === "HIGH" || level === "CRITICAL"
        ? { url, level, score, at: Date.now() }
        : stats.lastThreat,
    threatsBlocked:
      level === "HIGH" || level === "CRITICAL"
        ? (stats.threatsBlocked || 0) + 1
        : stats.threatsBlocked || 0,
  });

  if (
    settings.notifications &&
    (level === "HIGH" || level === "CRITICAL") &&
    urlResult.findings.length
  ) {
    const top = urlResult.findings[0];
    chrome.notifications.create(`pg-${tabId}-${Date.now()}`, {
      type: "basic",
      iconUrl: "icon.png",
      title: `PhishGuard · ${level}`,
      message: top.msg + (top.evidence ? ` (${top.evidence})` : ""),
      priority: 2,
    });
  }

  return {
    risk_level: level,
    risk_score: score,
    findings: urlResult.findings,
    host: urlResult.host,
    trusted: urlResult.trusted,
  };
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url) {
    evaluateTab(tabId, tab.url).catch(() => {});
  }
});

chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (tab.url) await evaluateTab(tab.id, tab.url);
  } catch (_) { /* ignore */ }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg?.type === "GET_SETTINGS") {
      sendResponse(await getSettings());
      return;
    }
    if (msg?.type === "SET_SETTINGS") {
      await chrome.storage.sync.set(msg.payload || {});
      sendResponse({ ok: true });
      return;
    }
    if (msg?.type === "ANALYZE_URL") {
      sendResponse(Engine.analyzeUrl(msg.url || ""));
      return;
    }
    if (msg?.type === "ANALYZE_TEXT") {
      const settings = await getSettings();
      sendResponse(Engine.analyzeText(msg.text || "", { sensitivity: settings.sensitivity }));
      return;
    }
    if (msg?.type === "PAGE_RESULT") {
      const settings = await getSettings();
      const tabId = sender.tab?.id;
      if (tabId != null && msg.result) {
        const level = msg.result.risk_level;
        const score = msg.result.risk_score || 0;
        const badge = badgeFor(level, score);
        await chrome.action.setBadgeText({ tabId, text: badge.text });
        await chrome.action.setBadgeBackgroundColor({ tabId, color: badge.color });
        if (
          settings.notifications &&
          (level === "HIGH" || level === "CRITICAL")
        ) {
          const top = (msg.result.findings || [])[0];
          chrome.notifications.create(`pg-page-${tabId}-${Date.now()}`, {
            type: "basic",
            iconUrl: "icon.png",
            title: `PhishGuard · ${level} page content`,
            message: top ? top.msg : "Suspicious page content detected",
          });
        }
      }
      sendResponse({ ok: true });
      return;
    }
    if (msg?.type === "ALLOWLIST_ADD") {
      const settings = await getSettings();
      const domain = (msg.domain || "").toLowerCase().replace(/^\./, "");
      if (domain && !settings.allowlist.includes(domain)) {
        settings.allowlist.push(domain);
        await chrome.storage.sync.set({ allowlist: settings.allowlist });
      }
      sendResponse({ allowlist: settings.allowlist });
      return;
    }
    if (msg?.type === "SCAN_TAB") {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) {
        sendResponse({ error: "No active tab" });
        return;
      }
      const urlEval = await evaluateTab(tab.id, tab.url || "");
      try {
        const [{ result }] = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            const text = (document.title || "") + "\n" + (document.body?.innerText || "");
            return text.slice(0, 20000);
          },
        });
        const settings = await getSettings();
        const page = Engine.analyzeText(result || "", { sensitivity: settings.sensitivity });
        // merge scores
        const mergedScore = Math.min(
          100,
          Math.max(urlEval?.risk_score || 0, page.risk_score || 0)
        );
        let level = "LOW";
        if (mergedScore >= 70) level = "CRITICAL";
        else if (mergedScore >= 50) level = "HIGH";
        else if (mergedScore >= 30) level = "MEDIUM";
        const badge = badgeFor(level, mergedScore);
        await chrome.action.setBadgeText({ tabId: tab.id, text: badge.text });
        await chrome.action.setBadgeBackgroundColor({ tabId: tab.id, color: badge.color });
        sendResponse({
          url: tab.url,
          urlEval,
          page,
          risk_score: mergedScore,
          risk_level: level,
        });
      } catch (e) {
        sendResponse({ url: tab.url, urlEval, error: String(e), risk_score: urlEval?.risk_score || 0, risk_level: urlEval?.risk_level || "LOW" });
      }
      return;
    }
    sendResponse({ error: "unknown message" });
  })();
  return true; // async
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get(DEFAULTS, (cur) => {
    chrome.storage.sync.set({ ...DEFAULTS, ...cur });
  });
});
