/**
 * PhishGuard content script — page scan, banner, form shield, link hover intel.
 */
(function () {
  "use strict";

  if (window.__phishguard_loaded) return;
  window.__phishguard_loaded = true;

  const STYLE_ID = "phishguard-styles";
  const BANNER_ID = "phishguard-banner";
  const TIP_ID = "phishguard-tip";

  function ensureStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const s = document.createElement("style");
    s.id = STYLE_ID;
    s.textContent = `
      #${BANNER_ID} {
        position: fixed; top: 0; left: 0; right: 0; z-index: 2147483646;
        display: flex; flex-wrap: wrap; align-items: center; justify-content: center; gap: 12px;
        padding: 14px 18px;
        font: 600 14px/1.4 Inter, system-ui, sans-serif;
        color: #e8eefc;
        background: linear-gradient(90deg, #0b1224 0%, #1a1030 50%, #0b1224 100%);
        border-bottom: 2px solid transparent;
        border-image: linear-gradient(90deg, #22d3ee, #8b5cf6) 1;
        box-shadow: 0 12px 40px rgba(0,0,0,0.45);
      }
      #${BANNER_ID} .pg-logo {
        width: 22px; height: 22px; border-radius: 6px;
      }
      #${BANNER_ID} .pg-level {
        font-size: 11px; letter-spacing: 0.08em; text-transform: uppercase;
        padding: 3px 8px; border-radius: 999px;
        background: rgba(244,63,94,0.18); color: #fb7185;
        border: 1px solid rgba(244,63,94,0.4);
      }
      #${BANNER_ID} .pg-level.high { background: rgba(251,113,133,0.15); color: #fda4af; }
      #${BANNER_ID} .pg-level.medium { background: rgba(245,158,11,0.15); color: #fbbf24; border-color: rgba(245,158,11,0.4); }
      #${BANNER_ID} button {
        font: 700 12px Inter, system-ui, sans-serif;
        border: none; border-radius: 8px; padding: 8px 14px; cursor: pointer;
      }
      #${BANNER_ID} .pg-dismiss {
        background: linear-gradient(135deg, #22d3ee, #8b5cf6); color: #041018;
      }
      #${BANNER_ID} .pg-allow {
        background: transparent; color: #67e8f9;
        border: 1px solid rgba(34,211,238,0.4) !important;
      }
      #${TIP_ID} {
        position: fixed; z-index: 2147483647; max-width: 320px;
        padding: 10px 12px; border-radius: 10px;
        font: 500 12px/1.4 Inter, system-ui, sans-serif;
        color: #e8eefc;
        background: #0d1424;
        border: 1px solid rgba(34,211,238,0.35);
        box-shadow: 0 12px 30px rgba(0,0,0,0.4);
        pointer-events: none;
      }
      #${TIP_ID} strong { color: #67e8f9; }
      .phishguard-link-risk {
        outline: 2px solid rgba(244,63,94,0.65) !important;
        outline-offset: 2px;
        border-radius: 2px;
      }
      #phishguard-form-shield {
        position: fixed; inset: 0; z-index: 2147483645;
        background: rgba(7,11,20,0.72);
        display: flex; align-items: center; justify-content: center;
        font: 500 14px Inter, system-ui, sans-serif; color: #e8eefc;
      }
      #phishguard-form-shield .box {
        max-width: 420px; margin: 16px; padding: 22px;
        background: #0d1424; border-radius: 16px;
        border: 1px solid rgba(139,92,246,0.4);
        box-shadow: 0 0 40px rgba(34,211,238,0.15);
      }
      #phishguard-form-shield h2 {
        margin: 0 0 8px; font-size: 18px;
        background: linear-gradient(135deg, #22d3ee, #8b5cf6);
        -webkit-background-clip: text; -webkit-text-fill-color: transparent;
      }
      #phishguard-form-shield button {
        margin: 8px 8px 0 0; padding: 10px 14px; border-radius: 10px;
        border: none; font-weight: 700; cursor: pointer;
      }
      #phishguard-form-shield .go {
        background: linear-gradient(135deg, #22d3ee, #8b5cf6); color: #041018;
      }
      #phishguard-form-shield .stop {
        background: transparent; color: #94a3b8; border: 1px solid #334155 !important;
      }
    `;
    (document.head || document.documentElement).appendChild(s);
  }

  function showBanner(result) {
    ensureStyles();
    if (document.getElementById(BANNER_ID)) return;
    const level = (result.risk_level || "HIGH").toUpperCase();
    const top = (result.findings && result.findings[0]) || { msg: "Suspicious content detected" };
    const el = document.createElement("div");
    el.id = BANNER_ID;
    el.innerHTML = `
      <span class="pg-level ${level.toLowerCase()}">${level}</span>
      <span><strong style="color:#67e8f9">PhishGuard</strong> · ${escapeHtml(top.msg)} · score ${result.risk_score || 0}</span>
      <button class="pg-dismiss" type="button">Dismiss</button>
      <button class="pg-allow" type="button">Trust this site</button>
    `;
    document.documentElement.appendChild(el);
    el.querySelector(".pg-dismiss").addEventListener("click", () => el.remove());
    el.querySelector(".pg-allow").addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "ALLOWLIST_ADD", domain: location.hostname });
      el.remove();
      const tip = document.createElement("div");
      tip.id = BANNER_ID;
      tip.innerHTML = `<span style="color:#34d399">Added ${escapeHtml(location.hostname)} to allowlist.</span>
        <button class="pg-dismiss" type="button">OK</button>`;
      document.documentElement.appendChild(tip);
      tip.querySelector(".pg-dismiss").addEventListener("click", () => tip.remove());
      setTimeout(() => tip.remove(), 2500);
    });
  }

  function escapeHtml(s) {
    return String(s || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  async function getSettings() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, (res) => {
        resolve(res || { enabled: true, formShield: true, linkHover: true, sensitivity: "balanced" });
      });
    });
  }

  async function scanPage() {
    const settings = await getSettings();
    if (!settings.enabled) return null;

    const allow = (settings.allowlist || []).some(
      (d) => location.hostname === d || location.hostname.endsWith("." + d)
    );
    if (allow) return null;

    // Prefer background engine for consistent rules
    const text = ((document.title || "") + "\n" + (document.body?.innerText || "")).slice(0, 22000);
    const result = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "ANALYZE_TEXT", text }, (res) => resolve(res));
    });

    if (!result) return null;

    // Local password form boost
    if (settings.formShield) {
      const untrusted = true; // background analyzeText already brands; form check local
      const hasPw = document.querySelector('input[type="password"]');
      if (hasPw && !isProbablyTrustedHost(location.hostname)) {
        result.findings = result.findings || [];
        result.findings.unshift({
          cat: "password_form",
          sev: "high",
          score: 22,
          msg: "Password field on potentially untrusted host",
        });
        result.risk_score = Math.min(100, (result.risk_score || 0) + 18);
        if (result.risk_score >= 50 && result.risk_level === "LOW") result.risk_level = "MEDIUM";
        if (result.risk_score >= 55) result.risk_level = result.risk_level === "CRITICAL" ? "CRITICAL" : "HIGH";
      }
    }

    chrome.runtime.sendMessage({ type: "PAGE_RESULT", result });

    if (result.risk_level === "HIGH" || result.risk_level === "CRITICAL") {
      showBanner(result);
    }

    if (settings.linkHover) markRiskyLinks();
    if (settings.formShield) installFormShield(result);

    return result;
  }

  function isProbablyTrustedHost(host) {
    const trusted = [
      "google.com", "microsoft.com", "live.com", "outlook.com", "apple.com",
      "icloud.com", "amazon.com", "paypal.com", "github.com", "facebook.com",
      "linkedin.com", "solviedoquantum.com",
    ];
    const h = (host || "").toLowerCase();
    return trusted.some((t) => h === t || h.endsWith("." + t));
  }

  function markRiskyLinks() {
    const anchors = document.querySelectorAll("a[href^='http']");
    anchors.forEach((a) => {
      const href = a.href;
      chrome.runtime.sendMessage({ type: "ANALYZE_URL", url: href }, (res) => {
        if (!res || res.score < 28) return;
        a.classList.add("phishguard-link-risk");
        a.dataset.pgScore = String(res.score);
        a.dataset.pgMsg = (res.findings && res.findings[0] && res.findings[0].msg) || "Risky link";
      });
    });
  }

  function installHoverTips() {
    let tip = null;
    document.addEventListener(
      "mouseover",
      (e) => {
        const a = e.target?.closest?.("a.phishguard-link-risk");
        if (!a) {
          const t = document.getElementById(TIP_ID);
          if (t) t.remove();
          return;
        }
        ensureStyles();
        tip = document.getElementById(TIP_ID) || document.createElement("div");
        tip.id = TIP_ID;
        tip.innerHTML = `<strong>PhishGuard</strong><br/>Score ${escapeHtml(a.dataset.pgScore || "?")}<br/>${escapeHtml(a.dataset.pgMsg || "")}`;
        document.documentElement.appendChild(tip);
        const rect = a.getBoundingClientRect();
        tip.style.left = Math.min(window.innerWidth - 340, Math.max(8, rect.left)) + "px";
        tip.style.top = Math.min(window.innerHeight - 80, rect.bottom + 8) + "px";
      },
      true
    );
  }

  let formShieldArmed = false;
  function installFormShield(result) {
    if (formShieldArmed) return;
    if (!result || (result.risk_score || 0) < 40) return;
    if (isProbablyTrustedHost(location.hostname)) return;
    formShieldArmed = true;

    document.addEventListener(
      "submit",
      (e) => {
        const form = e.target;
        if (!(form instanceof HTMLFormElement)) return;
        if (!form.querySelector('input[type="password"]')) return;
        if (sessionStorage.getItem("pg_form_ok_" + location.hostname)) return;
        e.preventDefault();
        e.stopPropagation();
        ensureStyles();
        if (document.getElementById("phishguard-form-shield")) return;
        const overlay = document.createElement("div");
        overlay.id = "phishguard-form-shield";
        overlay.innerHTML = `
          <div class="box">
            <h2>Credential shield</h2>
            <p>PhishGuard detected a password form on a site that looks risky (score ${result.risk_score}, ${result.risk_level}).
            Scammers use fake login pages to steal credentials.</p>
            <p style="color:#94a3b8;font-size:13px">Only continue if you intentionally navigated here and trust this domain: <code>${escapeHtml(location.hostname)}</code></p>
            <button type="button" class="stop">Stay safe — cancel</button>
            <button type="button" class="go">I trust this site — submit</button>
          </div>`;
        document.documentElement.appendChild(overlay);
        overlay.querySelector(".stop").onclick = () => overlay.remove();
        overlay.querySelector(".go").onclick = () => {
          sessionStorage.setItem("pg_form_ok_" + location.hostname, "1");
          overlay.remove();
          HTMLFormElement.prototype.submit.call(form);
        };
      },
      true
    );
  }

  // Boot
  ensureStyles();
  installHoverTips();

  const run = () => {
    scanPage().catch(() => {});
  };
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", run);
  } else {
    run();
  }

  // Gmail / SPA support
  let scheduled = false;
  const mo = new MutationObserver(() => {
    if (scheduled) return;
    scheduled = true;
    setTimeout(() => {
      scheduled = false;
      run();
    }, 1200);
  });
  const startObs = () => {
    if (document.body) mo.observe(document.body, { childList: true, subtree: true });
  };
  if (document.body) startObs();
  else document.addEventListener("DOMContentLoaded", startObs);
})();
