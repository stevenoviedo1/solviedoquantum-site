const DEFAULTS = {
  enabled: true,
  sensitivity: "balanced",
  notifications: true,
  formShield: true,
  linkHover: true,
  allowlist: [],
};

function load() {
  chrome.storage.sync.get(DEFAULTS, (s) => {
    document.getElementById("enabled").checked = s.enabled !== false;
    document.getElementById("notifications").checked = s.notifications !== false;
    document.getElementById("formShield").checked = s.formShield !== false;
    document.getElementById("linkHover").checked = s.linkHover !== false;
    document.getElementById("sensitivity").value = s.sensitivity || "balanced";
    document.getElementById("allowlist").value = (s.allowlist || []).join("\n");
  });
}

function save() {
  const allowlist = document
    .getElementById("allowlist")
    .value.split(/\r?\n/)
    .map((l) => l.trim().toLowerCase().replace(/^https?:\/\//, "").split("/")[0])
    .filter(Boolean);

  chrome.storage.sync.set(
    {
      enabled: document.getElementById("enabled").checked,
      notifications: document.getElementById("notifications").checked,
      formShield: document.getElementById("formShield").checked,
      linkHover: document.getElementById("linkHover").checked,
      sensitivity: document.getElementById("sensitivity").value,
      allowlist,
    },
    () => {
      const el = document.getElementById("saved");
      el.style.opacity = "1";
      setTimeout(() => {
        el.style.opacity = "0";
      }, 1600);
    }
  );
}

document.addEventListener("DOMContentLoaded", () => {
  load();
  document.getElementById("save").addEventListener("click", save);
});
