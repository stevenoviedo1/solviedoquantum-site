/**
 * PhishGuard shared browser rules engine (MV3 service worker + content scripts).
 * Mirrors key signals from detector.py for real-time protection without network calls.
 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) {
    module.exports = factory();
  } else {
    root.PhishGuardEngine = factory();
  }
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  const SUSPICIOUS_TLDS = [
    ".top", ".xyz", ".fun", ".online", ".click", ".link", ".gq", ".tk",
    ".ml", ".cf", ".ga", ".work", ".rest", ".surf", ".monster", ".icu",
    ".buzz", ".zip", ".mov", ".loan", ".win",
  ];

  const FREE_HOSTS = [
    "github.io", "netlify.app", "vercel.app", "web.app", "pages.dev",
    "firebaseapp.com", "ngrok.io", "trycloudflare.com", "glitch.me", "herokuapp.com",
  ];

  const PATH_FLAGS = [
    "login", "signin", "sign-in", "verify", "secure", "account", "update",
    "confirm", "password", "wallet", "billing", "unlock", "recover", "webscr",
  ];

  const BRANDS = [
    { name: "PayPal", keys: ["paypal"], legit: ["paypal.com", "paypal.me"] },
    { name: "Microsoft", keys: ["microsoft", "outlook", "office 365", "onedrive"], legit: ["microsoft.com", "live.com", "outlook.com", "office.com", "microsoftonline.com", "onedrive.com"] },
    { name: "Apple", keys: ["apple id", "icloud", "apple support"], legit: ["apple.com", "icloud.com"] },
    { name: "Amazon", keys: ["amazon", "prime membership"], legit: ["amazon.com", "amazonaws.com"] },
    { name: "Google", keys: ["google account", "gmail", "google drive"], legit: ["google.com", "gmail.com", "googleapis.com", "gstatic.com"] },
    { name: "Netflix", keys: ["netflix"], legit: ["netflix.com"] },
    { name: "Coinbase", keys: ["coinbase", "metamask", "binance"], legit: ["coinbase.com", "metamask.io", "binance.com"] },
  ];

  const TRUSTED = [
    "google.com", "gmail.com", "microsoft.com", "live.com", "outlook.com",
    "apple.com", "icloud.com", "amazon.com", "paypal.com", "github.com",
    "linkedin.com", "wikipedia.org", "solviedoquantum.com", "quantumstockgame.com",
  ];

  const KEYWORD_RULES = [
    { cat: "cloud_storage", score: 34, sev: "high", terms: ["cloud storage", "backups are at risk", "upgrade your storage", "storage has reached", "drive sync disabled"] },
    { cat: "verification", score: 32, sev: "high", terms: ["confirm your email", "verify your account", "action required immediately", "verify your identity", "secure your profile"] },
    { cat: "payment", score: 33, sev: "high", terms: ["invoice overdue", "payment failed", "update your billing", "account will be suspended"] },
    { cat: "tech_support", score: 40, sev: "critical", terms: ["your computer has a virus", "call this number immediately", "remote assistance", "windows defender alert"] },
    { cat: "prize", score: 30, sev: "high", terms: ["you have won", "claim your prize", "lottery winner", "claim reward"] },
    { cat: "crypto", score: 42, sev: "critical", terms: ["seed phrase", "recovery phrase", "connect your wallet", "private key", "airdrop claim"] },
    { cat: "credential", score: 38, sev: "critical", terms: ["enter your password", "re-enter password", "ssn required", "routing number"] },
    { cat: "tax", score: 40, sev: "critical", terms: ["irs refund", "tax refund pending", "warrant for arrest"] },
    { cat: "time_pressure", score: 18, sev: "medium", terms: ["expires in a few hours", "act now", "limited time", "final notice", "last chance"] },
  ];

  function normalizeHost(host) {
    if (!host) return "";
    let h = String(host).toLowerCase().replace(/\.$/, "");
    if (h.startsWith("www.")) h = h.slice(4);
    return h;
  }

  function registrable(host) {
    const h = normalizeHost(host);
    const parts = h.split(".").filter(Boolean);
    if (parts.length <= 2) return h;
    // naive eTLD+1 (good enough for client heuristics)
    return parts.slice(-2).join(".");
  }

  function isTrusted(host) {
    const h = normalizeHost(host);
    const reg = registrable(h);
    return TRUSTED.some((t) => reg === t || h === t || h.endsWith("." + t) || reg.endsWith("." + t));
  }

  function parseUrl(raw) {
    try {
      const u = new URL(raw.startsWith("http") ? raw : "http://" + raw);
      return u;
    } catch {
      return null;
    }
  }

  function levenshtein(a, b) {
    if (a === b) return 0;
    const m = a.length, n = b.length;
    const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;
    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;
        dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
      }
    }
    return dp[m][n];
  }

  function analyzeUrl(urlStr) {
    const findings = [];
    const u = parseUrl(urlStr);
    if (!u) {
      return { findings: [{ cat: "malformed", sev: "medium", score: 10, msg: "Malformed URL" }], score: 10 };
    }
    const host = normalizeHost(u.hostname);
    const path = (u.pathname + u.search).toLowerCase();

    if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) {
      findings.push({ cat: "ip_url", sev: "high", score: 28, msg: "Raw IP address host", evidence: host });
    }
    if (host.includes("xn--")) {
      findings.push({ cat: "punycode", sev: "high", score: 30, msg: "Punycode/IDN host", evidence: host });
    }
    for (const tld of SUSPICIOUS_TLDS) {
      if (host.endsWith(tld)) {
        findings.push({ cat: "tld", sev: "medium", score: 16, msg: "Abuse-prone TLD " + tld, evidence: host });
        break;
      }
    }
    if (FREE_HOSTS.some((h) => host === h || host.endsWith("." + h))) {
      if (PATH_FLAGS.some((f) => path.includes(f))) {
        findings.push({ cat: "free_host_login", sev: "high", score: 26, msg: "Login path on free hosting", evidence: host + path.slice(0, 40) });
      }
    }
    if (!isTrusted(host) && PATH_FLAGS.some((f) => path.includes(f))) {
      findings.push({ cat: "path_bait", sev: "medium", score: 12, msg: "Auth-like path on untrusted host", evidence: path.slice(0, 60) });
    }
    if (host.split(".").length >= 5 && !isTrusted(host)) {
      findings.push({ cat: "deep_subdomain", sev: "medium", score: 14, msg: "Deep subdomain chain", evidence: host });
    }
    if (u.username || (u.href.includes("@") && u.href.indexOf("@") < u.href.indexOf(host))) {
      findings.push({ cat: "userinfo", sev: "high", score: 24, msg: "URL userinfo spoof pattern", evidence: host });
    }

    // Brand typosquat
    for (const brand of BRANDS) {
      const core = brand.legit[0].split(".")[0];
      for (const label of host.split(".")) {
        if (!label || label === "www" || label.length < 4) continue;
        const dist = levenshtein(label, core);
        if (dist > 0 && dist <= 2 && !brand.legit.some((d) => host === d || host.endsWith("." + d))) {
          findings.push({ cat: "typosquat", sev: "critical", score: 34, msg: `Possible ${brand.name} typosquat`, evidence: host });
          break;
        }
      }
    }

    const byCat = {};
    for (const f of findings) byCat[f.cat] = Math.max(byCat[f.cat] || 0, f.score);
    let score = Object.values(byCat).reduce((a, b) => a + b, 0);
    score = Math.min(100, score);
    return { findings, score, host, trusted: isTrusted(host) };
  }

  function analyzeText(text, opts) {
    opts = opts || {};
    const sensitivity = opts.sensitivity || "balanced";
    const lower = (text || "").toLowerCase();
    const findings = [];

    for (const rule of KEYWORD_RULES) {
      let hit = null;
      for (const t of rule.terms) {
        if (lower.includes(t)) { hit = t; break; }
      }
      if (hit) {
        findings.push({
          cat: rule.cat,
          sev: rule.sev,
          score: rule.score,
          msg: `${rule.cat.replace(/_/g, " ")}: "${hit}"`,
          evidence: hit,
        });
      }
    }

    // Extract URLs
    const urlRe = /https?:\/\/[^\s<>"')\]]+/gi;
    const urls = (text || "").match(urlRe) || [];
    const urlResults = [];
    for (const raw of urls.slice(0, 25)) {
      const cleaned = raw.replace(/[.,;:!?)]+$/, "");
      const ur = analyzeUrl(cleaned);
      urlResults.push({ url: cleaned, ...ur });
      for (const f of ur.findings) findings.push({ ...f, evidence: cleaned.slice(0, 80) });
    }

    // Brand language + non-legit links
    for (const brand of BRANDS) {
      const mentioned = brand.keys.some((k) => lower.includes(k));
      if (!mentioned) continue;
      for (const ur of urlResults) {
        if (ur.trusted) continue;
        const ok = brand.legit.some((d) => ur.host === d || (ur.host || "").endsWith("." + d));
        if (!ok && ur.host) {
          findings.push({
            cat: "brand_impersonation",
            sev: "critical",
            score: 36,
            msg: `${brand.name} language with non-official host`,
            evidence: ur.host,
          });
          break;
        }
      }
    }

    if (/bit\.ly|tinyurl\.com|t\.co\/|is\.gd|cutt\.ly|rb\.gy/i.test(lower)) {
      findings.push({ cat: "shortener", sev: "medium", score: 14, msg: "URL shortener hides destination" });
    }

    const byCat = {};
    for (const f of findings) byCat[f.cat] = Math.max(byCat[f.cat] || 0, f.score);
    let score = Object.values(byCat).reduce((a, b) => a + b, 0);
    const mult = sensitivity === "strict" ? 1.15 : sensitivity === "quiet" ? 0.85 : 1;
    score = Math.min(100, Math.round(score * mult));

    let offset = sensitivity === "strict" ? -8 : sensitivity === "quiet" ? 10 : 0;
    let level = "LOW";
    if (score >= 70 + offset) level = "CRITICAL";
    else if (score >= 50 + offset) level = "HIGH";
    else if (score >= 30 + offset) level = "MEDIUM";

    return {
      risk_score: score,
      risk_level: level,
      findings: findings.sort((a, b) => b.score - a.score),
      urls: urlResults,
      sensitivity,
    };
  }

  function analyzePage(doc) {
    const title = doc.title || "";
    const bodyText = (doc.body && doc.body.innerText) || "";
    const sample = (title + "\n" + bodyText).slice(0, 25000);
    const result = analyzeText(sample);

    // Credential forms on non-trusted hosts
    try {
      const host = location.hostname;
      if (!isTrusted(host)) {
        const passwords = doc.querySelectorAll('input[type="password"]');
        if (passwords.length > 0) {
          result.findings.unshift({
            cat: "password_form",
            sev: "high",
            score: 22,
            msg: "Password field on untrusted site",
            evidence: host,
          });
          result.risk_score = Math.min(100, result.risk_score + 22);
          if (result.risk_score >= 50 && result.risk_level === "LOW") result.risk_level = "HIGH";
          if (result.risk_score >= 70) result.risk_level = "CRITICAL";
        }
      }
    } catch (_) { /* ignore */ }

    return result;
  }

  return {
    analyzeUrl,
    analyzeText,
    analyzePage,
    isTrusted,
    normalizeHost,
    VERSION: "2.0.0",
  };
});
